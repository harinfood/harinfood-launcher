package com.harinfood.launcher

import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.animation.ValueAnimator
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.animation.LinearInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.ImageView
import android.widget.PopupMenu
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    private var allApps: List<AppItem> = emptyList()
    private lateinit var adapter: AppAdapter
    private lateinit var search: EditText
    private lateinit var grid: RecyclerView
    private val logoAnimators = mutableListOf<ObjectAnimator>()

    // Daftar aplikasi dimuat ulang otomatis saat ada aplikasi dipasang / dicopot / diperbarui
    private val packageReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            loadApps()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        search = findViewById(R.id.search)
        grid = findViewById(R.id.app_grid)

        adapter = AppAdapter(
            onClick = { launchApp(it) },
            onLongClick = { anchor, item -> showAppMenu(anchor, item) }
        )
        grid.layoutManager = GridLayoutManager(this, 4)
        grid.adapter = adapter
        grid.setHasFixedSize(true)

        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                applyFilter()
            }
        })
        // Tekan tombol cari di keyboard: kalau hasilnya tinggal satu, langsung dibuka
        search.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                val result = filtered()
                if (result.size == 1) launchApp(result[0])
                hideKeyboard()
                true
            } else false
        }

        setupDock()
        setupLogoAnimation()
        loadApps()

        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addDataScheme("package")
        }
        ContextCompat.registerReceiver(this, packageReceiver, filter, ContextCompat.RECEIVER_EXPORTED)
    }

    override fun onStart() {
        super.onStart()
        logoAnimators.forEach { if (it.isPaused) it.resume() }
    }

    override fun onStop() {
        super.onStop()
        logoAnimators.forEach { if (it.isRunning) it.pause() }
    }

    override fun onDestroy() {
        super.onDestroy()
        logoAnimators.forEach { it.cancel() }
        try {
            unregisterReceiver(packageReceiver)
        } catch (_: Exception) {
        }
    }

    // Tombol Home ditekan saat launcher sudah terbuka: kembali ke posisi awal
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.action == Intent.ACTION_MAIN && intent.hasCategory(Intent.CATEGORY_HOME)) {
            search.setText("")
            search.clearFocus()
            hideKeyboard()
            grid.scrollToPosition(0)
        }
    }

    // Launcher tidak boleh "keluar" saat Back ditekan
    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        if (search.text.isNotEmpty()) {
            search.setText("")
            search.clearFocus()
            hideKeyboard()
        }
    }

    // ---------- Daftar aplikasi ----------

    private fun loadApps() {
        thread {
            val pm = packageManager
            val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val list = pm.queryIntentActivities(query, 0)
                .filter { it.activityInfo.packageName != packageName }
                .map {
                    AppItem(
                        label = it.loadLabel(pm).toString(),
                        packageName = it.activityInfo.packageName,
                        component = android.content.ComponentName(
                            it.activityInfo.packageName, it.activityInfo.name
                        ),
                        icon = it.loadIcon(pm)
                    )
                }
                .sortedBy { it.label.lowercase() }
            runOnUiThread {
                allApps = list
                applyFilter()
            }
        }
    }

    private fun filtered(): List<AppItem> {
        val q = search.text.toString().trim()
        return if (q.isEmpty()) allApps else allApps.filter { it.label.contains(q, ignoreCase = true) }
    }

    private fun applyFilter() {
        adapter.submit(filtered())
    }

    private fun launchApp(item: AppItem) {
        val intent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
            component = item.component
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        }
        try {
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "Aplikasi tidak bisa dibuka", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showAppMenu(anchor: View, item: AppItem) {
        val menu = PopupMenu(this, anchor)
        menu.menu.add(0, 1, 0, "Info aplikasi")
        menu.menu.add(0, 2, 1, "Copot pemasangan")
        menu.setOnMenuItemClickListener {
            val uri = Uri.parse("package:${item.packageName}")
            try {
                when (it.itemId) {
                    1 -> startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, uri))
                    2 -> startActivity(Intent(Intent.ACTION_DELETE, uri))
                }
            } catch (e: Exception) {
                Toast.makeText(this, "Tidak bisa membuka menu ini", Toast.LENGTH_SHORT).show()
            }
            true
        }
        menu.show()
    }

    // ---------- Dock (aplikasi bawaan HP) ----------

    private fun setupDock() {
        bindDock(R.id.dock_phone, Intent(Intent.ACTION_DIAL))
        bindDock(R.id.dock_sms, Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MESSAGING))
        bindDock(R.id.dock_browser, Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_BROWSER))
        bindDock(R.id.dock_camera, Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA))
    }

    private fun bindDock(viewId: Int, intent: Intent) {
        val view = findViewById<ImageView>(viewId)
        val info = packageManager.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY)
        if (info == null) {
            view.visibility = View.GONE
            return
        }
        view.setImageDrawable(info.loadIcon(packageManager))
        view.setOnClickListener {
            try {
                startActivity(Intent(intent).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (e: Exception) {
                Toast.makeText(this, "Aplikasi tidak ditemukan", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // ---------- Animasi logo Harinfood ----------
    // Cincin api berputar + aura berdenyut + logo "bernapas" (hanya transform/alpha, ringan)

    private fun setupLogoAnimation() {
        val ring = findViewById<View>(R.id.logo_ring)
        val aura = findViewById<View>(R.id.logo_aura)
        val logo = findViewById<View>(R.id.logo_img)

        logoAnimators += ObjectAnimator.ofFloat(ring, View.ROTATION, 0f, 360f).apply {
            duration = 2600
            interpolator = LinearInterpolator()
            repeatCount = ValueAnimator.INFINITE
        }
        logoAnimators += ObjectAnimator.ofPropertyValuesHolder(
            aura,
            PropertyValuesHolder.ofFloat(View.SCALE_X, 0.9f, 1.35f),
            PropertyValuesHolder.ofFloat(View.SCALE_Y, 0.9f, 1.35f),
            PropertyValuesHolder.ofFloat(View.ALPHA, 0.35f, 1f)
        ).apply {
            duration = 1100
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
        }
        logoAnimators += ObjectAnimator.ofPropertyValuesHolder(
            logo,
            PropertyValuesHolder.ofFloat(View.SCALE_X, 1f, 1.07f),
            PropertyValuesHolder.ofFloat(View.SCALE_Y, 1f, 1.07f)
        ).apply {
            duration = 1600
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
        }
        logoAnimators.forEach { it.start() }
    }

    private fun hideKeyboard() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(search.windowToken, 0)
    }
}
