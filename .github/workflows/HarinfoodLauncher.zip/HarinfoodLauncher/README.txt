HARINFOOD LAUNCHER (Android)
============================
Launcher layar utama bertema kedai Harinfood (oranye, logo beranimasi, kartu putih membulat).

CARA MEMBUAT APK
1. Pasang Android Studio (versi terbaru) di laptop/PC.
2. File > Open > pilih folder HarinfoodLauncher ini. Tunggu "Gradle sync" selesai
   (butuh internet; kalau muncul tawaran "Update AGP/Gradle", boleh diterima).
3. Menu Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK ada di app/build/outputs/apk/debug/app-debug.apk -> kirim ke HP dan pasang.

CARA MEMAKAI
- Buka Pengaturan HP > Aplikasi > Aplikasi default > Aplikasi layar utama
  (atau tekan tombol Home lalu pilih "Harinfood Launcher" > Selalu).
- Ketuk aplikasi untuk membuka, tekan lama untuk Info aplikasi / Copot pemasangan.
- Ketik di kolom cari; tekan tombol cari di keyboard untuk langsung membuka jika hasilnya satu.

Untuk kembali ke launcher bawaan: Pengaturan > Aplikasi default > Aplikasi layar utama.
